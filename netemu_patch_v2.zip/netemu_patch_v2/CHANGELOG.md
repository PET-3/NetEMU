# NetEMU 补丁 v2（完整可替换文件）

## 本补丁内容（全部为完整文件，直接覆盖即可）

### 新增能力
1. **连续丢包双模式**：包数 / 时间（参考暮雪辞）
2. **协议过滤**：全部 / 仅 TCP / 仅 UDP
3. **控制悬浮窗 + 信息悬浮窗**（可拖动）
4. **实时速度统计**
5. **改进的 Root/tc 规则**（HTB 优先 + TBF 回退）
6. **新预设**：间歇断网(时间)、仅UDP弱网

### 文件清单（完整可替换）

#### Flutter
- `lib/models/network_config.dart`
- `lib/models/backend_status.dart`
- `lib/services/native_bridge.dart`
- `lib/services/config_service.dart`
- `lib/services/network_controller.dart`
- `lib/screens/home_screen.dart`
- `lib/widgets/direction_card.dart`
- `lib/widgets/protocol_and_float_section.dart`
- `lib/widgets/stat_tile.dart`

#### Android
- `android/app/src/main/AndroidManifest.xml`
- `android/app/src/main/kotlin/com/netemu/netemu/MainActivity.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/backend/ShellBackend.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/emulator/EmulatorConfig.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/emulator/EmulatorStats.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/emulator/NetworkEmulator.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/float/FloatWindowService.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/vpn/NetEmuVpnService.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/vpn/PacketUtil.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/vpn/TcpProxy.kt`
- `android/app/src/main/kotlin/com/netemu/netemu/vpn/UdpProxy.kt`

### 使用
1. 解压后按路径直接覆盖项目对应文件
2. `flutter pub get && flutter analyze`
3. `flutter build apk --release --target-platform android-arm64`

### 注意
- 首次使用悬浮窗需授予「显示在其他应用上层」
- Root 模式主要影响上行；完整上下行推荐 VPN
- Shizuku 完整 API 仍需自行接入官方库（当前为检测 + shell 回退）
